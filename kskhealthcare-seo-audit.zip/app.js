// SEO Audit Report Interactive Features

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupCircularProgressBars();
    setupScrollSpy();
    setupMobileMenu();
    
    // Auto-expand first critical issue
    const firstCriticalIssue = document.querySelector('.issue-card[data-priority="critical"]');
    if (firstCriticalIssue) {
        toggleIssue(firstCriticalIssue.querySelector('.issue-header'));
    }
    
    // Auto-expand first recommendation section
    const firstRecommendation = document.querySelector('.rec-section');
    if (firstRecommendation) {
        toggleRecommendation(firstRecommendation.querySelector('.rec-header'));
    }
}

// Navigation and Smooth Scrolling
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            // Add active class to clicked link
            this.classList.add('active');
            
            // Smooth scroll to target section
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                const headerOffset = 100;
                const elementPosition = targetSection.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                closeMobileMenu();
            }
        });
    });
}

// Scroll Spy - Update navigation based on scroll position
function setupScrollSpy() {
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.nav-link');
    
    const observerOptions = {
        root: null,
        rootMargin: '-20% 0px -60% 0px',
        threshold: 0
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                
                // Remove active class from all nav links
                navLinks.forEach(link => link.classList.remove('active'));
                
                // Add active class to corresponding nav link
                const activeLink = document.querySelector(`.nav-link[href="#${id}"]`);
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });
    }, observerOptions);
    
    sections.forEach(section => {
        observer.observe(section);
    });
}

// Mobile Menu Toggle
function setupMobileMenu() {
    const navToggle = document.getElementById('navToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (navToggle && sidebar) {
        navToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            this.classList.toggle('active');
            
            // Animate hamburger icon
            const spans = this.querySelectorAll('span');
            if (this.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    }
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (sidebar && sidebar.classList.contains('open') && 
            !sidebar.contains(e.target) && 
            !navToggle.contains(e.target)) {
            closeMobileMenu();
        }
    });
}

function closeMobileMenu() {
    const sidebar = document.getElementById('sidebar');
    const navToggle = document.getElementById('navToggle');
    
    if (sidebar && sidebar.classList.contains('open')) {
        sidebar.classList.remove('open');
        navToggle.classList.remove('active');
        
        // Reset hamburger icon
        const spans = navToggle.querySelectorAll('span');
        spans[0].style.transform = 'none';
        spans[1].style.opacity = '1';
        spans[2].style.transform = 'none';
    }
}

// Circular Progress Bars Animation
function setupCircularProgressBars() {
    const scoreCircles = document.querySelectorAll('.score-circle, .score-circle-small');
    
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.5
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateProgressCircle(entry.target);
            }
        });
    }, observerOptions);
    
    scoreCircles.forEach(circle => {
        observer.observe(circle);
    });
}

function animateProgressCircle(circle) {
    const score = parseInt(circle.getAttribute('data-score')) || 0;
    let currentScore = 0;
    const increment = score / 50; // Animation duration control
    
    // Determine color based on score
    let color;
    if (score >= 85) {
        color = '#059669'; // excellent green
    } else if (score >= 70) {
        color = '#10b981'; // success green
    } else if (score >= 50) {
        color = '#f59e0b'; // warning orange
    } else {
        color = '#ef4444'; // error red
    }
    
    const animation = setInterval(() => {
        currentScore += increment;
        if (currentScore >= score) {
            currentScore = score;
            clearInterval(animation);
        }
        
        // Update CSS custom property for conic-gradient
        circle.style.setProperty('--score', currentScore);
        
        // Update background gradient
        const gradientStop = currentScore * 3.6; // Convert to degrees
        if (circle.classList.contains('score-circle')) {
            circle.style.background = `conic-gradient(from 0deg, ${color} 0deg, ${color} ${gradientStop}deg, rgba(255,255,255,0.2) ${gradientStop}deg)`;
        } else {
            circle.style.background = `conic-gradient(from 0deg, ${color} 0deg, ${color} ${gradientStop}deg, #e5e7eb ${gradientStop}deg)`;
            circle.style.color = color;
        }
    }, 20);
}

// Issue Card Toggle Functionality
function toggleIssue(header) {
    const issueCard = header.closest('.issue-card');
    const details = issueCard.querySelector('.issue-details');
    const expandIcon = header.querySelector('.expand-icon');
    
    if (issueCard.classList.contains('expanded')) {
        // Collapse
        issueCard.classList.remove('expanded');
        details.style.display = 'none';
        expandIcon.style.transform = 'rotate(0deg)';
    } else {
        // Expand
        issueCard.classList.add('expanded');
        details.style.display = 'block';
        expandIcon.style.transform = 'rotate(180deg)';
        
        // Animate the expansion
        details.style.opacity = '0';
        details.style.transform = 'translateY(-10px)';
        
        setTimeout(() => {
            details.style.opacity = '1';
            details.style.transform = 'translateY(0)';
            details.style.transition = 'all 0.3s ease';
        }, 10);
    }
}

// Recommendation Section Toggle
function toggleRecommendation(header) {
    const recSection = header.closest('.rec-section');
    const content = recSection.querySelector('.rec-content');
    const expandIcon = header.querySelector('.expand-icon');
    
    if (recSection.classList.contains('expanded')) {
        // Collapse
        recSection.classList.remove('expanded');
        content.style.display = 'none';
        expandIcon.style.transform = 'rotate(0deg)';
    } else {
        // Expand
        recSection.classList.add('expanded');
        content.style.display = 'block';
        expandIcon.style.transform = 'rotate(180deg)';
        
        // Animate the expansion
        content.style.opacity = '0';
        content.style.transform = 'translateY(-10px)';
        
        setTimeout(() => {
            content.style.opacity = '1';
            content.style.transform = 'translateY(0)';
            content.style.transition = 'all 0.3s ease';
        }, 10);
    }
}

// Tooltip functionality for technical terms
function setupTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(e) {
    const tooltipText = e.target.getAttribute('data-tooltip');
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = tooltipText;
    
    document.body.appendChild(tooltip);
    
    const rect = e.target.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
}

function hideTooltip() {
    const tooltip = document.querySelector('.tooltip');
    if (tooltip) {
        tooltip.remove();
    }
}

// Keyboard Navigation Support
function setupKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        // Handle keyboard navigation for expandable sections
        if (e.key === 'Enter' || e.key === ' ') {
            if (e.target.classList.contains('issue-header')) {
                e.preventDefault();
                toggleIssue(e.target);
            } else if (e.target.classList.contains('rec-header')) {
                e.preventDefault();
                toggleRecommendation(e.target);
            }
        }
        
        // Handle navigation shortcuts
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 'p':
                    e.preventDefault();
                    window.print();
                    break;
                case 'h':
                    e.preventDefault();
                    document.getElementById('executive-summary').scrollIntoView({ behavior: 'smooth' });
                    break;
            }
        }
    });
}

// Performance optimization - Lazy load images
function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Analytics and tracking (placeholder for real implementation)
function trackUserInteraction(action, element) {
    // This would integrate with analytics tools like Google Analytics
    console.log(`User action: ${action} on ${element}`);
}

// Add click tracking to important elements
function setupAnalytics() {
    document.addEventListener('click', function(e) {
        if (e.target.matches('.issue-header')) {
            trackUserInteraction('expand_issue', e.target.querySelector('h3').textContent);
        } else if (e.target.matches('.rec-header')) {
            trackUserInteraction('expand_recommendation', e.target.querySelector('h3').textContent);
        } else if (e.target.matches('.nav-link')) {
            trackUserInteraction('navigate_section', e.target.textContent);
        } else if (e.target.matches('.print-btn')) {
            trackUserInteraction('print_report', 'report');
        }
    });
}

// Initialize all features
setupKeyboardNavigation();
setupLazyLoading();
setupAnalytics();

// Export functions for global access
window.toggleIssue = toggleIssue;
window.toggleRecommendation = toggleRecommendation;